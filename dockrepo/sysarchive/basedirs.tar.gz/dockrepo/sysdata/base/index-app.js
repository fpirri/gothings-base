// super-simple nodejs http server
//   --> mantiene attivo il contenitore
//   --> e' chiamato "app" e gira nello contenitore "base" assieme ad altri server
//   --> user & app mostrano i contatori di entrambi i server attivi
//   --> sono anche esempi di comunicazione dati attraverso il 'keystore' redis
//
const http = require('http');     
const Redis = require('ioredis'); // inizializzazione redis

// ------------------------------------------ variabili globali
var mycountername = 'base:app:0.00.01:counter'   // this server main counter name
  , mycount = 0                        // this server main counter value
  , hiscountername = 'base:user:0.00.01:counter'  // counter name for the other server
  , hiscount = 0                       // counter value for the other server
  ;

// ---------------------------------------- definizioni ambiente
const serverport = 6003;             // definisce il server app
const serverhost = "0.0.0.0";
const port = 6379;                   // define & connect to redis
const host = 'redis';
const redis = new Redis(port, host);

// ---------------------------------------- funzioni asincrone redis
async function incrvar(varname) {// increment and read mycounter
    try {
        const value = await redis.incr(varname);
        return value;
    } catch (error) {
        return error;
    }
}
async function getvar(varname) {// read his counter
    try {
        const value = await redis.get(varname);
        return value;
    } catch (error) {
        return error;
    }
}

// ---------------------------------------- ciclo di lavoro server
http.createServer(async function (req, res) {
  try {
    //aspetta il contatore
    mycount = await incrvar(mycountername);
    hiscount = await getvar(hiscountername);
    // costruisci ed emetti la pagina
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write('<head><title>Hlite thing app service</title></head><body>\n')
    res.write('------------------ A P P -----------------<br><br>');
    res.write('Hello world!<br><br>');
    res.write('I am the main http server "app", running in the same base container as the "user" server<br>');
    res.write('I run on port '+serverport+'<br><br>');
    res.write('I am also able to count!<br>');
    res.write('I counted up to '+mycount+',<br>');
    res.write('while the other server counted up to '+hiscount+',<br><br>');
    res.write('I like to be called. Please call me again!<br>');
    res.write('<br><br>You called me as: <span id="url"></span>')
    res.write('<script>var idurl = document.getElementById("url");')
    res.write('idurl.insertAdjacentHTML("afterend", window.location.href);')
    res.write('</script></body>');
    res.end();
  } catch (error) {
    res.write('ERRORE on server "app" !!!<br>');
    res.end();
  }
}).listen(serverport, serverhost );
console.log('Server app now running on '+serverhost+':'+serverport);
