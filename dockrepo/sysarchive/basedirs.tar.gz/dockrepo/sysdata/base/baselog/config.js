/* 
 * file di configurazione per index-syslog.
 *
 */
const config = {
  http: { //                al momento NON USATO
    ip: '127.0.0.1',
    port: 80
  },
  baseurl: '/' //           prefisso alla chiamata
};

module.exports = config;
