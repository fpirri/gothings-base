/* 
 * template per il file di configurazione
 *
 */
const config = {
  app: {
    port: 80
  }
};

module.exports = config;
