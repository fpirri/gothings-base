/* 
 * funzioni di utilita' generica
 */

//var socket = io.connect("http://himage2.com:3000/espo");
//socket.on('message', function(d){console.log(d);});

function return_no_submit(){// copiare
  var i = 0
    , il = arguments.length
    , div_id
    ;
  if(il>0){
    for (; i < il; i++) {
      $('#'+arguments[i]).keypress(function(event) {// Il tasto enter non fa piu' submit
          return event.keyCode !== 13;
        }
      );
    }
  }
}

//---  DA:  http://stackoverflow.com/questions/171251/how-can-i-merge-properties-of-two-javascript-objects-dynamically
var fp_merge_objects = function() {
  var obj = {},
    i = 0,
    il = arguments.length,
    key;
  for (; i < il; i++) {
    for (key in arguments[i]) {
      if (arguments[i].hasOwnProperty(key)) {
        obj[key] = arguments[i][key];
      }
    }
  }
  return obj;
};

