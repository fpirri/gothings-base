#!/bin/bash
#
#  startup file per contenitore sviluppi vuejs
#
#############
#
echo
echo "base/baselog: lancio del server http/udp syslog"
node index-syslog.js
echo "ho eseguito:  node index-syslog.js"
echo "-----------------------------"
echo 
