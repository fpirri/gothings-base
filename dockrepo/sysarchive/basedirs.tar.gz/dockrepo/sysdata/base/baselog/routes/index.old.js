//  <root>/routes/user/index.js
//
//  manifest file per index-syslog.js
// 
var express = require('express')
  , router = express.Router();

router.get('/user/debug', require('./debug.js'));
router.get('/user', require('./userhome.js'));
router.get('/user/counter', require('./counter.js'));

module.exports = router;
