#!/bin/bash
#
#   Install node_modules from package.json
#
#   Run "npm list" at the end of update
#
#===============================================================================

echo 
echo "Start nodesyslog application ..........."
npm start
echo 
echo "nodesyslog started"