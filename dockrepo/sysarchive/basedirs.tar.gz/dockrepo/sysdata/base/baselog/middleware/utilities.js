//  <root>/middleware/utilities.js
//
var config = require('../config.js');

module.exports.csrf = function csrf(req, res, next){
  //console.log('utilities.csrf - Controllo gettone csrf');
  if(typeof req.csrfToken !== 'undefined'){
    console.log('utilities.csrf - token: '+req.csrfToken());
	  res.locals.Token = req.csrfToken();
  }else{
	  res.locals.Token = 'none';
    console.log('utilities - req.csrfToken() is undefined');
  }
//  ROBACCIA per prove varie
//  console.log('utilities - local csrf = : req.session.csrfSecret'+req.session.csrfSecret);
//	res.locals.Token = req.session.csrfSecret;
  //console.log('utilities - csrf - END ');
	next();
};

module.exports.authenticated = function authenticated(req, res, next){
  if(req.user.username === 'guest'){
    req.session.isAuthenticated = false;
  }else{
    req.session.isAuthenticated = req.session.passport.user !== undefined;
  }
  res.locals.isAuthenticated = req.session.isAuthenticated;
  if (req.session.isAuthenticated) {
    res.locals.user = req.session.passport.user;
  }
  next();
};


module.exports.requireAuthentication = function requireAuthentication(req, res, next){
	if (req.session.isAuthenticated) {
		next();
	}else {
		res.redirect(config.routes.login);
	}
};

//module.exports.auth = function auth(username, password, session){
//	var isAuth = username === 'joshua' || username === 'brian';
//	if (isAuth) {
//		session.isAuthenticated = isAuth;
//		session.user = {username: username};
//	}
//
//	return isAuth;
//};

module.exports.logOut = function logOut(req){
  req.session.isAuthenticated = false;
  req.session.destroy();
  //req.session = null;
  req.logout();
};

module.exports.templateRoutes = function templateRoutes(req, res, next){
	res.locals.routes = config.routes;

	next();
};

//---  DA:  http://stackoverflow.com/questions/171251/how-can-i-merge-properties-of-two-javascript-objects-dynamically
//  aggiunto per fare merge in stile jQuery.extend sul lato node
module.exports.fp_merge_objects = function fp_merge_objects() {
  var obj = {},
    i = 0,
    il = arguments.length,
    key;
  for (; i < il; i++) {
    for (key in arguments[i]) {
      if (arguments[i].hasOwnProperty(key)) {
        obj[key] = arguments[i][key];
      }
    }
  }
  return obj;
};

