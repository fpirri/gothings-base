#!/bin/bash
#
#  install nodejs modules for base apps
#
########
#  inherit: ???
#    
###
echo
echo "-----------------------"
echo "  Start GoThings BASE"
echo "-----------------------"
echo
#
local base message appdir
base="base"
message="install node js modules for GoThings BASE environment"
appdir="/home/pi/dockrepo/sysdata/base"
#
cd "${appdir}"
echo
echo "${base}: ${message}"
echo
echo "Starting docker-compose ..."
docker-compose -f /home/pi/dockrepo/sysdata/base/gothingsbaseinstall.yml up -d
echo
echo "${base}: ${message}"
echo "  DONE -----------------------------"
echo 