#!/bin/bash
#
#  startup file per contenitore sviluppi vuejs
#
#############
#
echo
echo "base: lancio del server app-http"
node index-app.js
echo "ho eseguito:  node index-app.js"
echo "-----------------------------"
echo 